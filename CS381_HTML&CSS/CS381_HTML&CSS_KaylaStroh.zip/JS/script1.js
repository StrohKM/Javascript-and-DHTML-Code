function opencard() {
  document.getElementById('outside').className = 'open-card';
}

function closecard() {
  document.getElementById('outside').className = '';
}